def print_log(message):
    print(f'The log added {message}')
